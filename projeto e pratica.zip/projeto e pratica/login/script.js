function showSection(sectionId) {
  const sections = document.querySelectorAll('main .section');
  sections.forEach(section => section.classList.remove('active'));

  const target = document.getElementById(sectionId);
  if (target) {
    target.classList.add('active');

    if (sectionId === 'dashboard') {
      updateDashboard();
    }
  }
}

function showSectionClass(sectionClass) {
  const sections = document.querySelectorAll('main .section');
  sections.forEach(section => section.classList.remove('active'));

  const targets = document.querySelectorAll(`main .${sectionClass}`);
  targets.forEach(target => target.classList.add('active'));
}
